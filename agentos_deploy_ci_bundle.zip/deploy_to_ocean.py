
import requests
import time
import paramiko
from python_dotenv import dotenv_values

# Configurações principais
TOKEN = "dop_v1_b7daf3f054c263e7ac2e13a4af30dcee4e07a19d762747778e2890e8b7b71396"
HEADERS = {"Authorization": f"Bearer {TOKEN}"}
SSH_KEY_NAME = "agentos-key"
DROPLET_NAME = "agentos-prod"
REGION = "nyc3"
SIZE = "s-2vcpu-4gb"
IMAGE = "docker-20-04"

# Criar Droplet
def create_droplet():
    ssh_keys = requests.get("https://api.digitalocean.com/v2/account/keys", headers=HEADERS).json()
    key_id = ssh_keys["ssh_keys"][0]["id"] if ssh_keys["ssh_keys"] else None

    data = {
        "name": DROPLET_NAME,
        "region": REGION,
        "size": SIZE,
        "image": IMAGE,
        "ssh_keys": [key_id] if key_id else [],
        "backups": False,
        "ipv6": True,
        "user_data": None,
        "private_networking": None,
        "tags": ["agentos"]
    }

    response = requests.post("https://api.digitalocean.com/v2/droplets", json=data, headers=HEADERS)
    droplet = response.json().get("droplet", {})
    print("Droplet criado. ID:", droplet.get("id"))
    return droplet.get("id")

# Obter IP do Droplet
def get_droplet_ip(droplet_id):
    while True:
        r = requests.get(f"https://api.digitalocean.com/v2/droplets/{droplet_id}", headers=HEADERS)
        droplet = r.json().get("droplet", {})
        networks = droplet.get("networks", {}).get("v4", [])
        for net in networks:
            if net["type"] == "public":
                return net["ip_address"]
        print("Aguardando IP público...")
        time.sleep(5)

# Conectar via SSH e rodar setup
def setup_server(ip):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip, username="root", key_filename="~/.ssh/id_rsa")

    cmds = [
        "apt update && apt install -y git",
        "git clone https://github.com/voulezvous-ai/AgentOS.git",
        "cd AgentOS && chmod +x init_deploy.sh && ./init_deploy.sh"
    ]
    for cmd in cmds:
        stdin, stdout, stderr = ssh.exec_command(cmd)
        print(stdout.read().decode(), stderr.read().decode())
    ssh.close()

if __name__ == "__main__":
    droplet_id = create_droplet()
    ip = get_droplet_ip(droplet_id)
    print("IP do servidor:", ip)
    setup_server(ip)
